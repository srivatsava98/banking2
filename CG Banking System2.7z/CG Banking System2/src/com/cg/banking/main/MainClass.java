package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws ClassNotFoundException {
		BankingServicesImpl bankingServicesImpl = new BankingServicesImpl();
		int choice=0;
		try{
			File file = new File("d:\\Banking.txt");
			if(file.exists())
				file.createNewFile();
			bankingServicesImpl.doreSerialization(file);;
		}catch(IOException e){
			e.printStackTrace();
		}
		while (choice!=14){
			try{	
				Scanner scanner = new Scanner(System.in);
				System.out.println("1. Enter Customer Details");
				System.out.println("2. Open Account");
				System.out.println("3. Deposit Amount");
				System.out.println("4. Withdraw Amount");
				System.out.println("5. Fund Transfer");
				System.out.println("6. Customer Details");
				System.out.println("7. Account Details");
				System.out.println("8. Transaction Details");
				System.out.println("9. Change Pin");
				System.out.println("10. Close Account");
				System.out.println("11. Generate Pin");
				System.out.println("12. Get All Customer Details");
				System.out.println("13. Get the Account Details of a customer");
				System.out.println("14. Account Status");
				System.out.println("15. Exit");
				
				choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("Enter first name");
					String firstName= scanner.next();
					System.out.println("Enter last name");
					String lastName= scanner.next();
					System.out.println("Enter emailId");
					String emailId= scanner.next();
					System.out.println("Enter panCard number");
					String panCard= scanner.next();
					System.out.println("Enter localAddress city");
					String localAddressCity= scanner.next();
					System.out.println("Enter localAddress state");
					String localAddressState= scanner.next();
					System.out.println("Enter localAddress pincode");
					int localAddressPinCode= scanner.nextInt();
					System.out.println("Enter Home Address city");
					String homeAddressCity= scanner.next();
					System.out.println("Enter Home Address state");
					String homeAddressState= scanner.next();
					System.out.println("Enter Home Address pincode");
					int homeAddressPinCode= scanner.nextInt();
					System.out.println("Customer Id " +bankingServicesImpl.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode));
					break;
				case 2:
					System.out.println("Enter the customerId");
					int customerId=scanner.nextInt();
					System.out.println("Enter the account type");
					String accountType=scanner.next();
					System.out.println("Enter the initial balance");
					float initBalance=scanner.nextFloat();
					System.out.println("Account no " +bankingServicesImpl.openAccount(customerId, accountType, initBalance));
					break;
				case 3:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please enter the account number");
					long accountNo=scanner.nextLong();
					System.out.println("Enter the amount to be deposited");
					float amount=scanner.nextFloat();
					System.out.println("Balance after deposit "+bankingServicesImpl.depositAmount(customerId, accountNo, amount)); 
					break;
				case 4:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please enter the account number");
					accountNo=scanner.nextLong();
					System.out.println("Enter the amount to be withdraw");
					amount=scanner.nextFloat();
					System.out.println("Please enter the PinNumber");
					int pinNumber=scanner.nextInt();
					System.out.println("Balance after withdraw "+bankingServicesImpl.withdrawAmount(customerId, accountNo, amount, pinNumber));
					break;
				case 5:
					System.out.println("Please enter the customerId from which amount to be transferred");
					int customerIdFrom=scanner.nextInt();
					System.out.println("Enter the account no from which to be tranferred");
					long accountNoFrom=scanner.nextLong();
					System.out.println("Enter the pin number");
					pinNumber=scanner.nextInt();
					System.out.println("Please enter the customerId to which amount to be transferred");
					int customerIdTo=scanner.nextInt();
					System.out.println("Enter the account no to which to be tranferred");
					long accountNoTo=scanner.nextLong();
					System.out.println("Please enter the amount to be transferred");
					float transferAmount=scanner.nextFloat();
					System.out.println(bankingServicesImpl.fundTransfer(customerIdTo, accountNoTo, customerIdFrom, accountNoFrom, transferAmount, pinNumber));
					break;
				case 6:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Details of the customer "+bankingServicesImpl.getCustomerDetails(customerId));
					break;
				case 7:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					System.out.println("Customer Account Details "+bankingServicesImpl.getAccountDetails(customerId, accountNo));
					break;
				case 8:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					for (Transaction transaction : bankingServicesImpl.getAccountAllTransaction(customerId, accountNo)) {
					System.out.println(transaction);
					}
					break;
				case 9:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					System.out.println("Please Enter your old pin number");
					int oldPinNumber=scanner.nextInt();
					System.out.println("Please Enter the new pin number");
					int newPinNumber=scanner.nextInt();
					System.out.println("Changed pin "+bankingServicesImpl.changeAccountPin(customerId, accountNo, oldPinNumber, newPinNumber));
					break;
				case 10:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					System.out.println(bankingServicesImpl.closeAccount(customerId, accountNo));
					break;
				case 11:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					System.out.println("Your Pin Number is "+bankingServicesImpl.generateNewPin(customerId, accountNo));
					break;
				case 12:
					for (Customer customer : bankingServicesImpl.getAllCustomerDetails()){ 
						System.out.println(customer);
					}
					break;
				case 13:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					for (Account account : bankingServicesImpl.getcustomerAllAccountDetails(customerId)) {
						System.out.println(account);
					}
					break;
				case 14:
					System.out.println("Enter the customerId");
					customerId=scanner.nextInt();
					System.out.println("Please Enter the AccountNo");
					accountNo=scanner.nextLong();
					System.out.println(bankingServicesImpl.accountStatus(customerId, accountNo));
					break;	
				case 15:
					try{
						File file = new File("d:\\Banking.txt");
						if(file.exists())
							file.createNewFile();
						bankingServicesImpl.doSerialization(file);
						}catch(IOException e) {
							e.printStackTrace();
						}
					break;
				}
			}
			catch (AccountBlockedException e) {
				e.printStackTrace();
			}
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			catch (BankingServicesDownException e) {
				e.printStackTrace();
			}
			catch (CustomerNotFoundException e) {
				e.printStackTrace();
			}
			catch (InsufficientAmountException e) {
				e.printStackTrace();
			}
			catch (InvalidAccountTypeException e) {
				e.printStackTrace();
			}
			catch (InvalidAmountException e) {
				e.printStackTrace();
			}
			catch (InvalidPinNumberException e) {
				e.printStackTrace();
			}
		}		
	}
}






/*try{
		BankingServicesImpl bankingServicesImpl = new BankingServicesImpl();
		int a=bankingServicesImpl.acceptCustomerDetails("M", "S", "sri@abc.com", "FFQPS2110", "Hyd", "TG", 500018, "Pune", "Maharashtra", 500018);
		int d=bankingServicesImpl.acceptCustomerDetails("V", "J", "sri@abc.com", "FFqqqq123", "Hyd", "TG", 345467, "delhi", "delhi", 123456);
		System.out.println(a);
		System.out.println(d);
		long b=bankingServicesImpl.openAccount(111, "Savings", 6000f);
		System.out.println(b);
		System.out.println(bankingServicesImpl.getCustomerDetails(a).getAccounts()[0].getAccountNo());
		long c=bankingServicesImpl.openAccount(111, "Savings", 8000f);
		long e=bankingServicesImpl.openAccount(112, "Salary", 5000f);
	    System.out.println(bankingServicesImpl.generateNewPin(111, 1234568));
	    System.out.println(bankingServicesImpl.generateNewPin(111, 1234567));
		System.out.println(bankingServicesImpl.getCustomerDetails(a).getAccounts()[0].getAccountNo());
		System.out.println(bankingServicesImpl.getCustomerDetails(d).getAccounts()[0].getAccountNo());
		System.out.println(bankingServicesImpl.depositAmount(111, 1234567, 8000f));
		System.out.println(bankingServicesImpl.withdrawAmount(a, b, 5000, bankingServicesImpl.getAccountDetails(a, b).getPinNumber()));
		System.out.println(bankingServicesImpl.withdrawAmount(d, e, 2000, bankingServicesImpl.getAccountDetails(d, e).getPinNumber()));
		System.out.println(bankingServicesImpl.changeAccountPin(a, b, bankingServicesImpl.getAccountDetails(a, b).getPinNumber(), 1234));
		System.out.println(bankingServicesImpl.fundTransfer(a, b, d, e, 1000, bankingServicesImpl.getAccountDetails(a, b).getPinNumber()));
		System.out.println(bankingServicesImpl.fundTransfer(d, e, a, b, 1000, bankingServicesImpl.getAccountDetails(d, e).getPinNumber()));
		System.out.println(b+" "+c);
		System.out.println(bankingServicesImpl.getAccountDetails(a, b));
		System.out.println(bankingServicesImpl.getcustomerAllAccountDetails(a)[1]);
		System.out.println(bankingServicesImpl.getcustomerAllAccountDetails(d)[0]);
		Transaction transa[]=bankingServicesImpl.getAccountAllTransaction(a, b);
		for (Transaction transaction : transa) {
			System.out.println(transaction);

		}
		Transaction transac[]=bankingServicesImpl.getAccountAllTransaction(d, e);
		for (Transaction transaction : transac) {
			System.out.println(transaction);

		}
		System.out.println(bankingServicesImpl.closeAccount(a, c));
		}
		catch(Exception e){
			e.printStackTrace();
		}*/


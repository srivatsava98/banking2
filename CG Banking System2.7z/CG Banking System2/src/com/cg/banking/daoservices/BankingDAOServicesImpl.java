package com.cg.banking.daoservices;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utilities.BankingUtilities;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static HashMap<Integer, Customer> customerList = new HashMap<>();
	//private static int CUSTOMER_ID_COUNTER=111;
	//private static long ACCOUNT_ID_COUNTER=1234567l;
	//private static int TRANSACTION_ID_COUNTER=4567;
	static Random rand = new Random();
	@Override
	public int insertCustomer(Customer customer) {
		//BankingUtilities.CUSTOMER_ID_COUNTER = BankingUtilities.CUSTOMER_ID_COUNTER+customerList.size();
		customer.setCustomerId(BankingUtilities.CUSTOMER_ID_COUNTER);
		customerList.put(BankingUtilities.CUSTOMER_ID_COUNTER++, customer);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		customerList.get(customerId).getAccountList().put(BankingUtilities.ACCOUNT_ID_COUNTER, account);
		customerList.get(customerId).getAccountList().get(BankingUtilities.ACCOUNT_ID_COUNTER).setAccountNo(BankingUtilities.ACCOUNT_ID_COUNTER++);
		account.setStatus("Active");
		return account.getAccountNo();
	}
	
	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(BankingUtilities.ACCOUNT_ID_COUNTER, account);
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getCustomer(customerId).getAccountList().get(account.getAccountNo()).setPinNumber(rand.nextInt(10000));	
		return account.getPinNumber();
	}
	
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		customerList.get(customerId).getAccountList().get(accountNo).getTransactionList().put(BankingUtilities.TRANSACTION_ID_COUNTER, transaction);
		customerList.get(customerId).getAccountList().get(accountNo).getTransactionList().get(BankingUtilities.TRANSACTION_ID_COUNTER).setTransactionId(BankingUtilities.TRANSACTION_ID_COUNTER++);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customerList.remove(customerId);
		return true;
	}	

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customerList.get(customerId).getAccountList().remove(accountNo);
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customerList.get(customerId).getAccountList().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customerList.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(customerList.get(customerId).getAccountList().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactionList().values());
	}
	public void doSerialization(File file) throws FileNotFoundException, IOException {	
		if(customerList.size()==0)
			return;
		try(ObjectOutputStream dest = new ObjectOutputStream(new FileOutputStream(file))){
		dest.writeObject(customerList);
		}	
	}
	public void doreSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		if(file.length()==0)
			return ;
		try(ObjectInputStream src = new ObjectInputStream(new FileInputStream(file))){
		customerList = (HashMap<Integer, Customer>)src.readObject();
		BankingUtilities.CUSTOMER_ID_COUNTER = Collections.max(customerList.keySet())+1;
		}
	}
}
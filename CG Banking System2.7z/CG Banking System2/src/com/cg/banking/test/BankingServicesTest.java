package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utilities.BankingUtilities;


public class BankingServicesTest {
	private static BankingServicesImpl bankingServicesImpl;
	@BeforeClass
	public static void setUpTestEnv(){
		bankingServicesImpl = new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(BankingUtilities.CUSTOMER_ID_COUNTER++);
		Customer customer2 = new Customer("V", "J", "vj@gmail.com", "FFQPS2111F", new Address(411062, "Pune", "Maharashtra"), new Address(500123, "Hyderabad", "TG"));
		customer2.setCustomerId(BankingUtilities.CUSTOMER_ID_COUNTER++);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(BankingUtilities.ACCOUNT_ID_COUNTER++);
		Account account2 = new Account("Salary", 2500f);
		account2.setAccountNo(BankingUtilities.ACCOUNT_ID_COUNTER++);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(BankingUtilities.TRANSACTION_ID_COUNTER++);
		Transaction transaction2= new Transaction(1000f, "deposit");	
		transaction2.setTransactionId(BankingUtilities.TRANSACTION_ID_COUNTER++);
		customer1.getAccountList().put(account1.getAccountNo(), account1);
		customer2.getAccountList().put(account2.getAccountNo(), account2);
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		customer2.getAccountList().put(account2.getAccountNo(), account2).getTransactionList().put(transaction2.getTransactionId(), transaction2);
		//BankingDAOServicesImpl.customerList.put(customer1.getCustomerId(), customer1);
		//BankingDAOServicesImpl.customerList.put(customer2.getCustomerId(), customer2);
	}
	@Test
	public void testforCustomerIdValid() throws CustomerNotFoundException, BankingServicesDownException{
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		assertEquals(customer1,bankingServicesImpl.getCustomerDetails(111));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testforCustomerIdInValid() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServicesImpl.getCustomerDetails(114);
	}
	@Test
	public void testforAccountNoValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		assertEquals(account1,bankingServicesImpl.getAccountDetails(111, 1234567));
	}
	@Test(expected = AccountNotFoundException.class)
	public void testforAccountNoInValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServicesImpl.getAccountDetails(112, 1234588);
	}
	@Test
	public void testAcceptCustomerdetails() {
		assertEquals(113, bankingServicesImpl.acceptCustomerDetails("M", "J", "mj@gmail.com", "FFQPS2110f", "Hyderabad", "TG", 500042, "Chennai", "TN", 123456));
	}
	@Test
	public void testgetCustomerAllDetailsValid() throws BankingServicesDownException, CustomerNotFoundException{
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		HashMap<Integer, Customer> customerMap = new HashMap<>();
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		customerMap.put(111, customer1);
		Customer customer2 = new Customer("V", "J", "vj@gmail.com", "FFQPS2111F", new Address(411062, "Pune", "Maharashtra"), new Address(500123, "Hyderabad", "TG"));
		customer2.setCustomerId(112);
		Account account2 = new Account("Salary", 2500f);
		account2.setAccountNo(1234568);
		Transaction transaction2= new Transaction(1000f, "deposit");	
		transaction2.setTransactionId(4568);
		customer2.getAccountList().put(account2.getAccountNo(), account2);
		customer2.getAccountList().put(account2.getAccountNo(), account2).getTransactionList().put(transaction2.getTransactionId(), transaction2);
		customerMap.put(112, customer2);
		ArrayList<Customer> customerList=new ArrayList<>(customerMap.values());
		//System.out.println(customerList);
		//System.out.println(bankingServicesImpl.getAllCustomerDetails());
		assertEquals(customerList,bankingServicesImpl.getAllCustomerDetails());
	}
	@Test
	public void testgetCustomerAllAccountDetails() throws BankingServicesDownException, CustomerNotFoundException{
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		ArrayList<Account> accounts = new ArrayList<>(customer1.getAccountList().values());
		assertEquals(accounts, bankingServicesImpl.getcustomerAllAccountDetails(111));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testgetCustomerAllaccountDetailsInvalid() throws BankingServicesDownException, CustomerNotFoundException{
	bankingServicesImpl.getcustomerAllAccountDetails(115);	
	}
	@Test
	public void testgetAccountAllTransDetailsValid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		ArrayList<Transaction> transactions = new ArrayList<>(customer1.getAccountList().get(account1.getAccountNo()).getTransactionList().values());
		assertEquals(transactions, bankingServicesImpl.getAccountAllTransaction(111, 1234567));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testgetAccountAllTransDetailsInvalid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServicesImpl.getAccountAllTransaction(116, 1234567);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testgetAccountAllTransDetailsInvalid1() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServicesImpl.getAccountAllTransaction(111, 1234577);
	}
	@Test
	public void testOpenAccountValid() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		assertEquals(1234569, bankingServicesImpl.openAccount(112, "Savings", 2000f));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testOpenAccountInValidCus() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServicesImpl.openAccount(116, "Savings", 2000f);
	}
	@Test(expected = InvalidAmountException.class)
	public void testOpenAccountInValidAmount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServicesImpl.openAccount(112, "Savings", 0f);
	}
	@Test(expected = InvalidAccountTypeException.class)
	public void testOpenAccountInValidAccount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServicesImpl.openAccount(112, "Other", 1000f);
	}
	@Test
	public void testDepositValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
	assertEquals(3000, bankingServicesImpl.depositAmount(111, 1234567, 1000f),100);
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testDepositInvalid1() throws CustomerNotFoundException,AccountNotFoundException,AccountBlockedException,BankingServicesDownException{
		bankingServicesImpl.depositAmount(123, 1234588, 1000);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testDepositInvalid2() throws CustomerNotFoundException,AccountNotFoundException,AccountBlockedException,BankingServicesDownException{
		bankingServicesImpl.depositAmount(111, 1234588, 1000);
	}
	@Test(expected = AccountBlockedException.class)
	public void testDepositInvalid3() throws CustomerNotFoundException,AccountNotFoundException,AccountBlockedException,BankingServicesDownException{
		bankingServicesImpl.getAccountDetails(111, 1234567).setStatus("Blocked");
		bankingServicesImpl.depositAmount(111, 1234567, 11111);
	}
	@Test
	public void testWithdrawValid() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		assertEquals(1000, bankingServicesImpl.withdrawAmount(111, 1234567, 1000, bankingServicesImpl.generateNewPin(111, 1234567)),0);
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testWithdrawInValidCus() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		bankingServicesImpl.withdrawAmount(117, 1234567, 1000, bankingServicesImpl.generateNewPin(111, 1234567));
	}
	@Test(expected = AccountNotFoundException.class)
	public void testWithdrawInValidAcc() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		bankingServicesImpl.withdrawAmount(111, 1234544, 1000, bankingServicesImpl.generateNewPin(111, 1234567));
	}
	@Test(expected = AccountBlockedException.class)
	public void testWithdrawInValidAccBl() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		bankingServicesImpl.getAccountDetails(111, 1234567).setStatus("Blocked");
		bankingServicesImpl.withdrawAmount(111, 1234567, 1000, bankingServicesImpl.generateNewPin(111, 1234567));
	}
	@Test(expected = InvalidPinNumberException.class)
	public void testWithdrawInValidPin() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		bankingServicesImpl.withdrawAmount(111, 1234567, 1000, 1234);
	}
	@Test(expected = InsufficientAmountException.class)
	public void testWithdrawInValidAmount() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		bankingServicesImpl.withdrawAmount(111, 1234567, 0, bankingServicesImpl.generateNewPin(111, 1234567));
	}
	@Test
	public void testFundTransferValid() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		assertTrue(bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234568, 120, bankingServicesImpl.generateNewPin(112, 1234568)));
	}
	@Test(expected = InsufficientAmountException.class)
	public void testFundTransferInValidAmount() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234568, 10000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = InvalidPinNumberException.class)
	public void testFundTransferInValidPin() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234568, 1000f, bankingServicesImpl.generateNewPin(111, 1234567));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testFundTransferInValidCus1() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(111, 1234567, 116, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testFundTransferInValidCus2() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(114, 1234567, 112, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testFundTransferInValidCus3() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(114, 1234567, 115, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = AccountNotFoundException.class)
	public void testFundTransferInValidAcc1() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234588, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = AccountNotFoundException.class)
	public void testFundTransferInValidAcc2() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.fundTransfer(111, 1234544, 112, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = AccountBlockedException.class)
	public void testFundTransferInValidAccBlock() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.getAccountDetails(111, 1234567).setStatus("Blocked");
		bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test(expected = AccountBlockedException.class)
	public void testFundTransferInValidAccBlock1() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServicesImpl.getAccountDetails(112, 1234568).setStatus("Blocked");
		bankingServicesImpl.fundTransfer(111, 1234567, 112, 1234568, 1000f, bankingServicesImpl.generateNewPin(112, 1234568));
	}
	@Test
	public void testChangeAccountPin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		assertTrue(bankingServicesImpl.changeAccountPin(111, 1234567, bankingServicesImpl.generateNewPin(111, 1234567), 1234));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testChangeAccountPinInvalidCus() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		bankingServicesImpl.changeAccountPin(117, 1234567, bankingServicesImpl.generateNewPin(111, 1234567), 5263);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testChangeAccountPinInvalidAcc() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		bankingServicesImpl.changeAccountPin(111, 1234568, bankingServicesImpl.generateNewPin(111, 1234567), 5263);
	}
	@Test(expected = InvalidPinNumberException.class)
	public void testChangeAccountPinInvalidPin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		bankingServicesImpl.changeAccountPin(111, 1234567, 7894, 5263);
	}
	@Test
	public void testAccountStatusvalid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServicesImpl.accountStatus(111, 1234567);
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testAccountStatusInvalidCus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServicesImpl.accountStatus(115, 1234567);
	}
	@Test(expected = AccountBlockedException.class)
	public void testAccountStatusInvalidAccountBlocked() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServicesImpl.getAccountDetails(111, 1234567).setStatus("Blocked");
		bankingServicesImpl.accountStatus(111, 1234567);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testAccountStatusInvalidAcc() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServicesImpl.accountStatus(111, 1234599);
	}
	@Test
	public void testCloseAccountValid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		assertTrue(bankingServicesImpl.closeAccount(111, 1234567));
	}
	@Test(expected = CustomerNotFoundException.class)
	public void testCloseAccountCusInValid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServicesImpl.closeAccount(118, 1234567);
	}
	@Test(expected = AccountNotFoundException.class)
	public void testCloseAccountAccInValid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServicesImpl.closeAccount(111, 1234569);
	}
	@After
	public void tearDown() {
		
		BankingUtilities.CUSTOMER_ID_COUNTER=111;
		BankingUtilities.ACCOUNT_ID_COUNTER=1234567;
		BankingUtilities.TRANSACTION_ID_COUNTER=4567;
	}
	@AfterClass
	public static void tearDownAfterClass(){
		bankingServicesImpl = null;
	}
}

package com.cg.banking.utilities;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingUtilities {
	public static int CUSTOMER_ID_COUNTER=111;
	public static long ACCOUNT_ID_COUNTER=1234567l;
	public static int TRANSACTION_ID_COUNTER=4567;
}
/*	Customer customer1 = new Customer("M", "S", "ms@gmail.com", "FFQPS2110f", new Address(411062, "Pune", "Maharashtra"), new Address(500018, "Hyderabad", "TG"));
		customer1.setCustomerId(111);
		Account account1 = new Account("Savings", 2000f);
		account1.setAccountNo(1234567);
		Transaction transaction1= new Transaction(1000f, "deposit");
		transaction1.setTransactionId(4567);
		HashMap<Integer, Customer> customerMap = new HashMap<>();
		customer1.getAccountList().put(account1.getAccountNo(), account1);	
		customer1.getAccountList().put(account1.getAccountNo(), account1).getTransactionList().put(transaction1.getTransactionId(), transaction1);
		customerMap.put(111, customer1);
		
		Customer customer2 = new Customer("V", "J", "vj@gmail.com", "FFQPS2111F", new Address(411062, "Pune", "Maharashtra"), new Address(500123, "Hyderabad", "TG"));
		customer2.setCustomerId(112);
		Account account2 = new Account("Salary", 2500f);
		account2.setAccountNo(1234568);
		Transaction transaction2= new Transaction(1000f, "deposit");	
		transaction2.setTransactionId(4568);
		
		customer2.getAccountList().put(account2.getAccountNo(), account2);
		
		customer2.getAccountList().put(account2.getAccountNo(), account2).getTransactionList().put(transaction2.getTransactionId(), transaction2);
		customerMap.put(112, customer2);
		
		ArrayList<Customer> customerList=new ArrayList<>(customerMap.values());
		System.out.println(customerList);
		System.out.println(bankingServicesImpl.getcustomerAllAccountDetails(111));
		assertEquals(customerList,bankingServicesImpl.getcustomerAllAccountDetails(111));
	}*/